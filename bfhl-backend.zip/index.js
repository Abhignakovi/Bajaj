const express = require('express');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;

// Root URL
app.get('/', (req, res) => {
  res.send('Welcome to the BFHL API. Use /bfhl endpoint.');
});

// POST /bfhl endpoint
app.post('/bfhl', (req, res) => {
  const { data } = req.body;
  const numbers = data.filter(item => !isNaN(item));
  const alphabets = data.filter(item => isNaN(item));

  let highestLowercase = alphabets
    .filter(char => char === char.toLowerCase())
    .sort()
    .pop() || '';

  res.json({
    is_success: true,
    user_id: 'abhigna',  
    email: 'koviabhi363@gmail.com',
    roll_number: '21BCE9365',
    numbers,
    alphabets,
    highest_lowercase_alphabet: [highestLowercase]
  });
});

app.get('/', (req, res) => {
  res.send('Welcome to the BFHL API. Use /bfhl endpoint.');
});


app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
